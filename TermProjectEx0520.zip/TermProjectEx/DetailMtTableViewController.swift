//
//  DetailMtTableViewController.swift
//  TermProjectEx
//
//  Created by kpugame on 2017. 5. 20..
//  Copyright © 2017년 ryuilsang. All rights reserved.
//

import UIKit

class DetailMtTableViewController: UITableViewController, XMLParserDelegate{
    

    @IBOutlet var detailTableView: UITableView!
    var url : String?
    var parser = XMLParser()
    let postsname : [String] = ["산이름","주소","상세정보","높이","산번호","산요약"]
    var posts : [String] = ["","","","","",""]
    var element = NSString()
    var mntiname = NSMutableString()
    var mntiadd = NSMutableString()
    var mntidetails = NSMutableString()
    var mntihigh = NSMutableString()
    var mntilistno = NSMutableString()
    var mntisummary = NSMutableString()
    func beginParsing()
    {
        posts = []
        parser = XMLParser(contentsOf:(URL(string:url!))!)!
        parser.delegate = self
        parser.parse()
        detailTableView.reloadData()
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        if (elementName as NSString).isEqual(to: "item")
        {
            posts = ["","","","","",""]
            mntiname = NSMutableString()
            mntiname = ""
            mntiadd = NSMutableString()
            mntiadd = ""
            mntidetails = NSMutableString()
            mntidetails = ""
            mntihigh = NSMutableString()
            mntihigh = ""
            mntilistno = NSMutableString()
            mntilistno = ""
            mntisummary = NSMutableString()
            mntisummary = ""
        }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "mntiname") {
            mntiname.append(string)
        } else if element.isEqual(to: "mntiadd"){
            mntiadd.append(string)
        } else if element.isEqual(to: "mntidetails"){
            mntidetails.append(string)
        } else if element.isEqual(to: "mntihigh"){
            mntihigh.append(string)
        } else if element.isEqual(to: "mntilistno"){
            mntilistno.append(string)
        } else if element.isEqual(to: "mntisummary"){
            mntisummary.append(string)
        }
    }
    func parser(_ parser: XMLParser, didEneElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item"){
            if !mntiname.isEqual(nil){
                posts[0] = mntiname as String
            }
            if !mntiadd.isEqual(nil){
                posts[1] = mntiadd as String
            }
            if !mntidetails.isEqual(nil){
                posts[2] = mntidetails as String
            }
            if !mntihigh.isEqual(nil){
                posts[3] = mntihigh as String
            }
            if !mntilistno.isEqual(nil){
                posts[4] = mntilistno as String
            }
            if !mntisummary.isEqual(nil){
                posts[5] = mntisummary as String
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        beginParsing()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return postsname.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "MtCell")!
        if(cell.isEqual(NSNull.self)){
            cell = Bundle.main.loadNibNamed("MtCell", owner: self, options: nil)?[0] as! UITableViewCell;
        }
        cell.textLabel?.text = postsname[indexPath.row]
        cell.detailTextLabel?.text = posts[indexPath.row]
        return cell as UITableViewCell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
