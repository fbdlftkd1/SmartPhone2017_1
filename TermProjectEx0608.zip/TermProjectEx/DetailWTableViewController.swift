//
//  DetailWTableViewController.swift
//  mtsearchApp
//
//  Created by kpugame on 2017. 6. 5..
//  Copyright © 2017년 ryuilsang. All rights reserved.
//

import UIKit

class DetailWTableViewController: UITableViewController, XMLParserDelegate {
    @IBOutlet var detailTableView: UITableView!
    var url : String?
    var parser = XMLParser()
    let postsname : [String] = ["기온", "습도", "풍향", "풍속", "강우량", "기압", "지면온도"]
    var posts : [String] = ["","","","","","",""]
    var element = NSString()
    var tm10m = NSMutableString()
    var hm10m = NSMutableString()
    var wd10m = NSMutableString()
    var ws10m = NSMutableString()
    var rn = NSMutableString()
    var pa = NSMutableString()
    var ts = NSMutableString()

    func beginParsing()
    {
        posts = []
        parser = XMLParser(contentsOf:(URL(string:url!))!)!
        parser.delegate = self
        parser.parse()
        detailTableView.reloadData()
        
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        if (elementName as NSString).isEqual(to: "outputData")
        {
            posts = ["","","","","","",""]
            tm10m = NSMutableString()
            tm10m = ""
            hm10m = NSMutableString()
            hm10m = ""
            wd10m = NSMutableString()
            wd10m = ""
            ws10m = NSMutableString()
            ws10m = ""
            rn = NSMutableString()
            rn = ""
            pa = NSMutableString()
            pa = ""
            ts = NSMutableString()
            ts = ""
            
        }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "tm10m") {
            tm10m.append(string)
        } else if element.isEqual(to: "hm10m") {
            hm10m.append(string)
        } else if element.isEqual(to: "wd10m") {
            wd10m.append(string)
        } else if element.isEqual(to: "ws10m") {
            ws10m.append(string)
        } else if element.isEqual(to: "rn") {
            rn.append(string)
        } else if element.isEqual(to: "pa") {
            pa.append(string)
        } else if element.isEqual(to: "ts") {
            ts.append(string)
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "outputData") {
            if !tm10m.isEqual(nil) {
                posts[0] = tm10m as String
            }
            if !hm10m.isEqual(nil) {
                posts[1] = hm10m as String
            }
            if !wd10m.isEqual(nil) {
                posts[2] = wd10m as String
            }
            if !ws10m.isEqual(nil) {
                posts[3] = ws10m as String
            }
            if !rn.isEqual(nil) {
                posts[4] = rn as String
            }
            if !pa.isEqual(nil) {
                posts[5] = pa as String
            }
            if !ts.isEqual(nil) {
                posts[6] = ts as String
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        beginParsing()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return postsname.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        var cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "wCell")!
        if(cell.isEqual(NSNull.self)) {
            cell = Bundle.main.loadNibNamed("wCell", owner: self, options: nil)?[0] as! UITableViewCell;
        }
        cell.textLabel?.text = postsname[indexPath.row]
        cell.detailTextLabel?.text = posts[indexPath.row]
        return cell as UITableViewCell
    }
    
    /*
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
     
     // Configure the cell...
     
     return cell
     }
     */
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
