//
//  ViewController.swift
//  mtsearchApp
//
//  Created by kpugame on 2017. 6. 4..
//  Copyright © 2017년 ryuilsang. All rights reserved.
//

import UIKit
import Speech
class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var myTextView: UITextView!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var transcribeButton: UIButton!
    @IBOutlet weak var pickerView: UIPickerView!
    private let speechRecognizer = SFSpeechRecognizer()!
    private var speechRecognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var speechRecognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    var pickerDataSource = ["서울특별시","세종특별자치시","부산광역시","대전광역시","울산광역시","경기도","강원도","충청남도","전라남도","전라북도","경상남도","경상북도","제주도"]
    var url : String = "http://know.nifos.go.kr/openapi/mtweather/mountListSearch.do?keyValue="
    var serviceKey : String = "9213096580909395515895027919901406575898"
    var url2 : String = "&version=1.0&localArea="
    var sgguCd : String = "1"
    var url3 : String = "&obsid="
    var areaNum : String = "1910"
    var url4 : String = "&tm="
    @IBAction func startTranscribing(_ sender: Any) {
        transcribeButton.isEnabled = false
        stopButton.isEnabled = true
        try! startSession()
    }
    @IBAction func stopTranscribing(_ sender: Any) {
        if audioEngine.isRunning {
            audioEngine.stop()
            speechRecognitionRequest?.endAudio()
            transcribeButton.isEnabled = true
            stopButton.isEnabled = false
        }
        switch (self.myTextView.text) {
        case "서울특별시" : self.pickerView.selectRow(0, inComponent: 0, animated: true)
            break
        case "세종특별자치시" : self.pickerView.selectRow(1, inComponent: 0, animated: true)
            break
        case "부산광역시" : self.pickerView.selectRow(2, inComponent: 0, animated: true)
            break
        case "대전광역시" : self.pickerView.selectRow(3, inComponent: 0, animated: true)
            break
        case "울산광역시" : self.pickerView.selectRow(4, inComponent: 0, animated: true)
            break
        case "경기도" : self.pickerView.selectRow(5, inComponent: 0, animated: true)
            break
        case "강원도" : self.pickerView.selectRow(6, inComponent: 0, animated: true)
            break
        case "충청남도" : self.pickerView.selectRow(7, inComponent: 0, animated: true)
            break
        case "전라남도" : self.pickerView.selectRow(8, inComponent: 0, animated: true)
            break
        case "전라북도" : self.pickerView.selectRow(9, inComponent: 0, animated: true)
            break
        case "경상남도" : self.pickerView.selectRow(10, inComponent: 0, animated: true)
            break
        case "경상북도" : self.pickerView.selectRow(11, inComponent: 0, animated: true)
            break
        case "제주도" : self.pickerView.selectRow(12, inComponent: 0, animated: true)
            break
        default: break
        }
    }
    
    @IBAction func doneToPickerViewController(segue:UIStoryboardSegue) {
    }
    func startSession() throws {
        if let recognitionTask = speechRecognitionTask {
            recognitionTask.cancel()
            self.speechRecognitionTask = nil
        }
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(AVAudioSessionCategoryRecord)
        
        speechRecognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        guard let recognitionRequest = speechRecognitionRequest else { fatalError("SFSpeechAudioBufferRecognitionRequest object creation failed") }
        
        guard let inputNode = audioEngine.inputNode else { fatalError("Audio engine has no input node") }
        recognitionRequest.shouldReportPartialResults = true
        speechRecognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            var finished = false
            if let result = result {
                self.myTextView.text = result.bestTranscription.formattedString
                finished = result.isFinal
            }
            if error != nil || finished {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.speechRecognitionRequest = nil
                self.speechRecognitionTask = nil
                self.transcribeButton.isEnabled = true
            }
        }
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
            self.speechRecognitionRequest?.append(buffer)
        }
        audioEngine.prepare()
        try audioEngine.start()
    }
    func authorizeSR() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus{
                case .authorized:
                    self.transcribeButton.isEnabled = true
                    
                case .denied:
                    self.transcribeButton.isEnabled = false
                    self.transcribeButton.setTitle("Speech recognition access denied by user", for: .disabled)
                    
                case .restricted:
                    self.transcribeButton.isEnabled = false
                    self.transcribeButton.setTitle("Speech recognition restricted on device", for: .disabled)
                    
                case .notDetermined:
                    self.transcribeButton.isEnabled = false
                    self.transcribeButton.setTitle("Speech recognition not authorized", for: .disabled)
                }
            }
        }
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerDataSource.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerDataSource[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if row == 0 {
            sgguCd = "1"
            areaNum = "1910"
        } else if row == 1 {
            sgguCd = "2"
            areaNum = "4910"
        } else if row == 2 {
            sgguCd = "3"
            areaNum = "8914"
        } else if row == 3 {
            sgguCd = "7"
            areaNum = "4912"
        } else if row == 4 {
            sgguCd = "8"
            areaNum = "8900"
        } else if row == 5 {
            sgguCd = "9"
            areaNum = "1890"
        } else if row == 6 {
            sgguCd = "10"
            areaNum = "31"
        } else if row == 7 {
            sgguCd = "11"
            areaNum = "4890"
        } else if row == 8 {
            sgguCd = "12"
            areaNum = "3891"
        } else if row == 9 {
            sgguCd = "13"
            areaNum = "6901"
        } else if row == 10 {
            sgguCd = "14"
            areaNum = "5909"
        } else if row == 11 {
            sgguCd = "15"
            areaNum = "8891"
        } else if row == 12 {
            sgguCd = "16"
            areaNum = "7891"
        } else if row == 13 {
            sgguCd = "17"
            areaNum = "9910"
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if segue.identifier == "segueToWDetail" {
            
                if let detailWTableViewController = segue.destination as? DetailWTableViewController {
                    detailWTableViewController.url = url + serviceKey + url2 + sgguCd + url3 + areaNum + url4
                
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pickerView.dataSource = self;
        self.pickerView.delegate = self;
        authorizeSR()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

