//
//  ViewController.swift
//  TermProjectEx
//
//  Created by kpugame on 2017. 5. 13..
//  Copyright © 2017년 ryuilsang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var url : String = "http://apis.data.go.kr/1400000/service/cultureInfoService/mntInfoOpenAPI?searchWrd="
    var serviceKey : String = "XI9dRrKsmlT5m%2F7vjgRXYPrD9V%2Ftyn25v%2B5%2F2QSHPHgcm21jEnDx1XKBOhq1ZdnQc5BglYTkZziN4JeeIPVlrg%3D%3D"

    var mntName = ""
    var mntName_utf8 = ""
    @IBOutlet var searchMTText : UITextField!
    @IBOutlet var Views: UIView!
    @IBAction func Out(_ sender: Any) {
    }
   
    @IBAction func cancel(segue: UIView) {
    }
    
    @IBAction func dontToPickerViewController(segue:UIStoryboardSegue){
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if segue.identifier == "segueToTableView" {
            if let navController = segue.destination as? UINavigationController {
                mntName = searchMTText.text!
                mntName_utf8 = mntName.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
                if let mtsTableViewController = navController.topViewController as? MTSTableViewController{
                    mtsTableViewController.url = url + mntName_utf8 + "&ServiceKey=" + serviceKey
                }
                
            }
        }
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

